# ENS Integration

This repository contains LGPL-3.0 licensed resources for integrating ENS with multi-chain support.

## Features
- Modify and deploy ENS contracts
- Multi-chain support (Base, BSC, and more)
- Easy-to-use implementation guide

## License
This project is licensed under the LGPL-3.0 License.
